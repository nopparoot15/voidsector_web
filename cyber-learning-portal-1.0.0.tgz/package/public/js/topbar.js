// public/js/topbar.js
// VOIDSECTOR Topbar + Notifications
// - Dropdown works WITHOUT JS via <details>/<summary>
// - With JS: close other menus on open, close on outside click/ESC, close buttons
// - Also: fetches /api/notify/summary to update badges + render Messages/Alerts like Facebook

(() => {
  const menus = Array.from(document.querySelectorAll('.vs-menu[data-menu]'));
  if (!menus.length) return;

  const menusByName = new Map(menus.map(m => [m.getAttribute('data-menu') || '', m]));
  const isLoggedIn = !!window.VS_ME;

  const nameOf = (el) => el.getAttribute('data-menu') || '';

  function closeAll(exceptName = null) {
    menus.forEach((m) => {
      if (exceptName && nameOf(m) === exceptName) return;
      m.removeAttribute('open');
    });
  }

  function setBadge(name, value) {
    const el = document.querySelector(`[data-badge="${name}"]`);
    if (!el) return;
    const n = Number(value) || 0;
    el.textContent = String(n);
    if (n > 0) el.removeAttribute('hidden');
    else el.setAttribute('hidden', 'hidden');
  }

  function escapeHtml(s) {
    return String(s ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function fmtTime(iso) {
    if (!iso) return '';
    try {
      const d = new Date(iso);
      const now = new Date();
      const diff = Math.floor((now - d) / 1000);
      if (diff < 60) return 'just now';
      if (diff < 3600) return `${Math.floor(diff / 60)}m`;
      if (diff < 86400) return `${Math.floor(diff / 3600)}h`;
      return d.toLocaleDateString();
    } catch {
      return '';
    }
  }

  // --------------------
  // Progressive enhancement for <details> menus
  // --------------------
  menus.forEach((menu) => {
    menu.addEventListener('toggle', () => {
      if (menu.hasAttribute('open')) closeAll(nameOf(menu));
    });
  });

  // Close buttons
  document.querySelectorAll('[data-menu-close]').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const menu = btn.closest('.vs-menu[data-menu]');
      if (!menu) return;
      menu.removeAttribute('open');
    });
  });

  // Close on outside click
  document.addEventListener('click', (e) => {
    const inside = e.target.closest('.vs-menu[data-menu]');
    if (!inside) closeAll(null);
  });

  // Close on ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeAll(null);
  });

  // --------------------
  // Renderers
  // --------------------
  function renderAlerts(friendRequests) {
    const list = document.getElementById('vsNotifList');
    if (!list) return;

    list.innerHTML = '';
    if (!friendRequests || friendRequests.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'vs-dd__empty';
      empty.textContent = 'No notifications yet';
      list.appendChild(empty);
      return;
    }

    friendRequests.forEach((fr) => {
      const div = document.createElement('div');
      div.className = 'vs-dd__item';
      div.innerHTML = `
        <div style="flex:1;">
          <div class="vs-dd__itemTitle">👋 Friend request</div>
          <div class="vs-dd__itemMeta"><b>${escapeHtml(fr.username)}</b> sent you a request · ${escapeHtml(fmtTime(fr.created_at))}</div>
        </div>
        <div class="vs-dd__pill">Review</div>
      `;
    });
  }

  function renderMessages(threads) {
    const list = document.getElementById('vsMessagesList');
    if (!list) return;

    list.innerHTML = '';
    if (!threads || threads.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'vs-dd__empty';
      empty.textContent = 'ยังไม่มีเพื่อน';
      list.appendChild(empty);
      return;
    }

    threads.forEach((t) => {
      const unread = Number(t.unread_count) || 0;
      const last = (t.last_message || '').trim();
      const lastLine = last ? last.slice(0, 80) : 'Start a conversation';
      const div = document.createElement('div');
      div.className = 'vs-dd__item vs-dd__item--message';
      div.dataset.openChat = 'dm';
      div.dataset.friendId = t.friend_id;
      div.dataset.friendName = t.username;
      div.dataset.roomId = t.room_id;

      div.innerHTML = `
        <div class="vs-dd__avatar">${escapeHtml((t.username || '?').slice(0,1).toUpperCase())}</div>
        <div class="vs-dd__msgMain">
          <div class="vs-dd__msgTop">
            <div class="vs-dd__itemTitle">👤 ${escapeHtml(t.username)}</div>
            <div class="vs-dd__time">${escapeHtml(fmtTime(t.last_at))}</div>
          </div>
          <div class="vs-dd__itemMeta">${escapeHtml(lastLine)}</div>
        </div>
        ${unread > 0 ? `<div class="vs-dd__unread">${unread}</div>` : ``}
      `;

      div.addEventListener('click', () => {
        location.href = `/dm?friend=${encodeURIComponent(t.friend_id)}`;
      });

      list.appendChild(div);
    });
  }

  // --------------------
  // Data: fetch summary + update UI
  // --------------------
  let lastSummary = null;
  let fetching = false;

  async function fetchSummary() {
    if (!isLoggedIn || fetching) return;
    fetching = true;
    try {
      const r = await fetch('/api/notify/summary', { credentials: 'include' });
      const j = await r.json().catch(() => null);
      if (!j || !j.ok) return;

      lastSummary = j;
      window.VS_NOTIFY = j;

      setBadge('notifications', j.counts?.alerts || 0);
      setBadge('messages', j.counts?.messages || 0);

      renderAlerts(j.friend_requests || []);
      renderMessages(j.dm_threads || []);
    } catch (e) {
      // ignore
    } finally {
      fetching = false;
    }
  }

  // initial
  fetchSummary();
  // poll (friend requests are not realtime)
  setInterval(fetchSummary, 15000);

  // If socket exists, refresh on new dm
  const hookSocket = () => {
    const s = window.VS_SOCKET || window.socket || null;
    if (!s || typeof s.on !== 'function') return;
    // when DM arrives and you are in the room view
    s.on('dm:new', () => fetchSummary());
    // when DM arrives but you are not in the room view
    s.on('dm:notify', () => fetchSummary());
  };
  hookSocket();

  // expose minimal API
  window.VS_TOPBAR = {
    closeAll,
    setBadge,
    refresh: fetchSummary,
    getSummary: () => lastSummary
  };
})();
