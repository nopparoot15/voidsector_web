// public/js/chat-dock.js
// -----------------------------------------------------------------------------
// Chat dock overlays (Global + DM) — Facebook style
// - Singleton init guard (script may be included multiple times)
// - Global chat uses socket event chat:send/chat:new
// - DM uses /api/dm/open + /api/dm/rooms/:id/messages + socket dm:join/dm:send/dm:new
// -----------------------------------------------------------------------------
(() => {
  if (window.__VS_CHAT_DOCK_INIT__) return;
  window.__VS_CHAT_DOCK_INIT__ = true;

  const dock = document.getElementById('chatDock');
  if (!dock) return;

  // ===== identity (from EJS) =====
  const MY_ID = window.VS_ME?.id ? Number(window.VS_ME.id) : null;
  const MY_NAME = norm(window.VS_ME?.username || '');

  // ===== socket (shared) =====
  let socket = null;
  let lastGlobalHistory = [];

  // DM registries
  const dmRoomByFriend = new Map(); // friendId -> roomId
  const dmKeyByRoom = new Map();    // roomId -> key

  function ensureSocket() {
    if (socket || typeof io !== 'function') return socket;
    socket = io({ withCredentials: true });
    window.VS_SOCKET = socket;

    socket.on('connect', () => {
      const username = String(window.VS_ME?.username || '').trim();
      if (username) socket.emit('chat:hello', { userId: MY_ID, username });
    });

    socket.on('chat:history', (rows) => {
      lastGlobalHistory = Array.isArray(rows) ? rows : [];
      const box = boxes.get('global');
      if (!box) return;
      renderGlobalHistory(box);
    });

    socket.on('chat:new', (row) => {
      const box = boxes.get('global');
      if (!box) return;
      const body = box.querySelector('.chat-box__body');
      appendMsg(body, {
        userId: row.userId ?? row.user_id ?? null,
        username: row.username,
        message: row.message
      });
      scrollToBottom(body);
    });

    socket.on('dm:new', (row) => {
      const rid = Number(row?.roomId);
      if (!rid) return;
      const key = dmKeyByRoom.get(rid);
      if (!key) return; // DM box not open
      const box = boxes.get(key);
      if (!box) return;
      const body = box.querySelector('.chat-box__body');
      appendMsg(body, {
        userId: row.userId ?? row.user_id ?? null,
        username: row.username,
        message: row.message
      });
      scrollToBottom(body);
      // refresh badges
      window.VS_TOPBAR?.refresh && window.VS_TOPBAR.refresh();
    });

    socket.on('dm:notify', () => window.VS_TOPBAR?.refresh && window.VS_TOPBAR.refresh());
    return socket;
  }

  // ===== small utils =====
  function norm(s) {
    return String(s || '').trim().toLowerCase();
  }
  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  async function postJson(url, body) {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(body || {})
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.ok === false) throw new Error(j.reason || j.message || 'request_failed');
    return j;
  }

  async function getJson(url) {
    const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.ok === false) throw new Error(j.reason || j.message || 'request_failed');
    return j;
  }

  // ===== chat box registry (prevent duplicates) =====
  const boxes = new Map(); // key -> element

  function openChatBox({ key, title, mode }) {
    if (boxes.has(key)) {
      const el = boxes.get(key);
      dock.appendChild(el);
      return el;
    }

    const box = document.createElement('div');
    box.className = 'chat-box';
    box.dataset.chatKey = key;
    box.dataset.mode = mode || 'global';

    box.innerHTML = `
      <div class="chat-box__head">
        <div class="chat-box__title"><span>${escapeHtml(title)}</span></div>
        <button type="button" aria-label="Close">✕</button>
      </div>
      <div class="chat-box__body"></div>
      <form class="chat-box__input" autocomplete="off">
        <input type="text" placeholder="พิมพ์ข้อความ..." maxlength="1000" />
        <button type="submit">Send</button>
      </form>
    `;

    const closeBtn = box.querySelector('.chat-box__head button');
    const body = box.querySelector('.chat-box__body');
    const form = box.querySelector('form');
    const input = box.querySelector('input');

    closeBtn.addEventListener('click', () => {
      boxes.delete(key);
      box.remove();
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const msg = String(input.value || '').trim();
      if (!msg) return;
      input.value = '';

      // optimistic UI
      appendMsg(body, { userId: MY_ID, username: window.VS_ME?.username || 'Me', message: msg });
      scrollToBottom(body);

      const modeNow = box.dataset.mode;

      if (modeNow === 'global') {
        const s = ensureSocket();
        if (s) s.emit('chat:send', { message: msg });
      } else if (modeNow === 'dm') {
        const roomId = Number(box.dataset.roomId);
        const s = ensureSocket();
        if (s && roomId) s.emit('dm:send', { roomId, message: msg });
      }
    });

    dock.appendChild(box);
    boxes.set(key, box);
    scrollToBottom(body);
    return box;
  }

  function appendMsg(bodyEl, { userId = null, username, message }) {
    const uRaw = String(username || '').trim();
    const u = norm(uRaw);

    // ✅ decide side (prefer userId)
    const isMe =
      (MY_ID !== null && userId !== null && Number(userId) === Number(MY_ID)) ||
      (MY_NAME && u === MY_NAME);

    const row = document.createElement('div');
    row.className = 'chat-box__msg ' + (isMe ? 'is-me' : 'is-other');

    row.innerHTML = `
      <div class="u">${escapeHtml(uRaw || 'Unknown')}</div>
      <div class="t">${escapeHtml(message || '')}</div>
    `;

    bodyEl.appendChild(row);
  }

  function scrollToBottom(bodyEl) {
    bodyEl.scrollTop = bodyEl.scrollHeight;
  }

  function renderGlobalHistory(box) {
    const body = box.querySelector('.chat-box__body');
    body.innerHTML = '';
    lastGlobalHistory.forEach(r => appendMsg(body, {
      userId: r.userId ?? r.user_id ?? null,
      username: r.username,
      message: r.message
    }));
    scrollToBottom(body);
  }

  async function openGlobal() {
    ensureSocket();
    const box = openChatBox({ key: 'global', title: '🌐 Global Chat', mode: 'global' });
    if (!box.dataset.bound) {
      box.dataset.bound = '1';
      if (lastGlobalHistory.length) renderGlobalHistory(box);
    }
    return box;
  }

  async function openDm(friendId, friendName = 'Friend') {
    ensureSocket();
    const fid = Number(friendId);
    if (!fid) return null;

    const key = `dm:${fid}`;
    const box = openChatBox({ key, title: `👤 ${friendName}`, mode: 'dm' });

    // open/get room id once
    if (!box.dataset.roomId) {
      try {
        const j = await postJson('/api/dm/open', { friend_id: fid });
        const rid = Number(j.room_id);
        if (rid) {
          box.dataset.roomId = String(rid);
          dmRoomByFriend.set(fid, rid);
          dmKeyByRoom.set(rid, key);

          // join room for realtime
          const s = ensureSocket();
          if (s) s.emit('dm:join', { roomId: rid });

          // load history and mark read
          const history = await getJson(`/api/dm/rooms/${rid}/messages?limit=60`);
          const body = box.querySelector('.chat-box__body');
          body.innerHTML = '';
          (history.messages || []).forEach(m => appendMsg(body, {
            userId: m.user_id ?? m.userId ?? null,
            username: m.username,
            message: m.message
          }));
          scrollToBottom(body);

          // refresh badges now that we marked read
          window.VS_TOPBAR?.refresh && window.VS_TOPBAR.refresh();
        }
      } catch (e) {
        const body = box.querySelector('.chat-box__body');
        body.innerHTML = `<div class="chat-box__sys">DM error: ${escapeHtml(e.message || e)}</div>`;
      }
    }

    return box;
  }

  // ===== integrate with topbar dropdown items =====
  document.addEventListener('click', (e) => {
    const item = e.target.closest('[data-open-chat]');
    if (!item) return;

    const type = item.getAttribute('data-open-chat');
    if (type === 'global') {
      openGlobal();
      return;
    }

    if (type === 'dm') {
      const fid = item.getAttribute('data-friend-id');
      const fname = item.getAttribute('data-friend-name') || 'Friend';
      if (!fid) return;
      openDm(fid, fname);
      return;
    }
  });

  // ===== expose for programmatic opening =====
  window.VS_CHAT_DOCK = {
    openGlobal,
    openDm,
  };
})();