// public/js/friends-page.js

async function jget(url) {
  const r = await fetch(url);
  return r.json();
}
async function jpost(url, body) {
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body || {})
  });
  return r.json();
}

const elIncoming = document.getElementById('incoming');
const elIncomingEmpty = document.getElementById('incomingEmpty');
const elFriends = document.getElementById('friends');
const elFriendsEmpty = document.getElementById('friendsEmpty');

const inputAdd = document.getElementById('addUsername');
const btnAdd = document.getElementById('btnAdd');
const addToast = document.getElementById('addToast');

function toast(msg) {
  addToast.textContent = msg || '';
}

function renderIncoming(items) {
  elIncoming.innerHTML = '';

  if (!items || items.length === 0) {
    elIncomingEmpty.style.display = 'block';
    return;
  }
  elIncomingEmpty.style.display = 'none';

  for (const it of items) {
    const row = document.createElement('div');
    row.className = 'item';
    row.innerHTML = `
      <div class="meta">
        <div style="font-weight:600;">${escapeHtml(it.username)}</div>
        <div class="muted">request id: ${it.id}</div>
      </div>
      <div class="row">
        <button class="secondary" data-accept="${it.id}">Accept</button>
        <button class="danger" data-decline="${it.id}">Decline</button>
      </div>
    `;
    elIncoming.appendChild(row);
  }
}

function renderFriends(items) {
  elFriends.innerHTML = '';

  if (!items || items.length === 0) {
    elFriendsEmpty.style.display = 'block';
    return;
  }
  elFriendsEmpty.style.display = 'none';

  for (const f of items) {
    const row = document.createElement('div');
    row.className = 'item';
    row.innerHTML = `
      <div class="meta">
        <div style="font-weight:600;">${escapeHtml(f.username)}</div>
        <div class="muted">id: ${f.id}</div>
      </div>
      <div class="row">
        <a class="link" href="/dm?friend=${encodeURIComponent(f.id)}">DM</a>
      </div>
    `;
    elFriends.appendChild(row);
  }
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

async function loadIncoming() {
  const r = await jget('/api/friends/requests/incoming');
  if (!r.ok) {
    renderIncoming([]);
    return;
  }
  renderIncoming(r.requests);
}

async function loadFriends() {
  const r = await jget('/api/friends/list');
  if (!r.ok) {
    renderFriends([]);
    return;
  }
  renderFriends(r.friends);
}

// Add friend
btnAdd.addEventListener('click', async () => {
  const username = inputAdd.value.trim();
  if (!username) return toast('กรอก username ก่อน');

  btnAdd.disabled = true;
  toast('กำลังส่งคำขอ...');

  const r = await jpost('/api/friends/request', { username });

  btnAdd.disabled = false;

  if (r.ok) {
    toast(`ส่งคำขอไปหา ${username} แล้ว`);
    inputAdd.value = '';
  } else {
    toast('ส่งคำขอไม่สำเร็จ (อาจไม่มี user / ส่งซ้ำ / ส่งให้ตัวเอง)');
  }

  // refresh incoming/friends
  await loadIncoming();
  await loadFriends();
});

// Click accept/decline
elIncoming.addEventListener('click', async (e) => {
  const acceptId = e.target.getAttribute('data-accept');
  const declineId = e.target.getAttribute('data-decline');

  if (acceptId) {
    e.target.disabled = true;
    await jpost(`/api/friends/requests/${acceptId}/accept`);
    await loadIncoming();
    await loadFriends();
  }

  if (declineId) {
    e.target.disabled = true;
    await jpost(`/api/friends/requests/${declineId}/decline`);
    await loadIncoming();
  }
});

(async function boot() {
  toast('');
  await loadIncoming();
  await loadFriends();
})();
