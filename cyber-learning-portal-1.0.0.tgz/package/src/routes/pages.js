// src/routes/pages.js
const express = require('express');
const router = express.Router();

const catalog = [
  { key: 'english', title: 'English Basic Course', desc: 'คอร์สอังกฤษพื้นฐาน + แบบทดสอบ', icon: '🇬🇧' },
  { key: 'coding', title: 'Python Master Class', desc: 'ทบทวน Python Phase 1-2 พร้อม quiz', icon: '🐍' }
];

// ------------------------------------------------------
// Landing gate: must login/register before entering the app
// ------------------------------------------------------
router.get('/', async (req, res) => {
  if (!req.session.user) {
    return res.render('pages/landing');
  }

  // After login, Home is a Tool Hub (Cyber Portal)
  res.render('pages/home', { catalog });
});

// From here on, all pages require login
router.use((req, res, next) => {
  if (!req.session.user) return res.redirect('/');
  next();
});

router.get('/learn', (req, res) => res.render('pages/learn', { catalog }));

router.get('/python-playground', (req, res) => {
  res.render('pages/python-playground');
});

router.get('/terminal', (req, res) => {
  res.render('pages/terminal');
});

router.get('/calculator', (req, res) => {
  res.render('pages/calculator');
});

router.get('/course/:category', (req, res) => {
  const category = req.params.category;
  const item = catalog.find(c => c.key === category);

  if (!item) {
    return res.status(404).render('pages/notfound');
  }

  res.render('pages/course', { category, item });
});

module.exports = router;
