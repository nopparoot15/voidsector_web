// src/server.js
require('dotenv').config();

const http = require('http');
const { Server } = require('socket.io');

const { createApp } = require('./app');
const { pool, initDb } = require('./config/db');

const app = createApp();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: true,
    credentials: true,
  }
});

// --------------------------------------------------
// Helper: check room membership (for DM privacy)
// --------------------------------------------------
async function isRoomMember(roomId, userId) {
  if (!roomId || !userId) return false;

  const r = await pool.query(
    `SELECT 1
     FROM chat_room_members
     WHERE room_id = $1 AND user_id = $2
     LIMIT 1`,
    [roomId, userId]
  );

  return r.rows.length > 0;
}

// --------------------
// Socket.IO - Global Chat + DM
// --------------------
io.on('connection', async (socket) => {
  console.log('✅ socket connected:', socket.id);

  // ตัวตนของ user ที่ผูกกับ socket นี้
  socket.data.userId = null;
  socket.data.username = null;

  // --------------------
  // Global chat history (room_id = 1)
  // --------------------
  try {
    const { rows } = await pool.query(`
      SELECT
        id,
        username,
        user_id,
        message,
        created_at
      FROM chat_messages
      WHERE room_id = 1
      ORDER BY id DESC
      LIMIT 30
    `);

    socket.emit('chat:history', rows.reverse());
  } catch (err) {
    console.error('chat:history error:', err.code || err.message);
    socket.emit('chat:history', []);
  }

  // --------------------
  // Identify user
  // --------------------
  socket.on('chat:hello', (payload) => {
    const rawId = payload?.userId;
    const userId = (rawId === null || rawId === undefined) ? null : Number(rawId);
    const username = String(payload?.username || '').trim().slice(0, 32);

    if (!username) {
      socket.emit('chat:error', { message: 'Missing username (chat:hello)' });
      return;
    }

    socket.data.userId = Number.isFinite(userId) ? userId : null;
    socket.data.username = username;

    // Personal room for notifications
    if (socket.data.userId) {
      socket.join(`user:${socket.data.userId}`);
    }

    socket.emit('chat:me', {
      userId: socket.data.userId,
      username: socket.data.username
    });
  });

  // --------------------
  // Global chat send
  // --------------------
  socket.on('chat:send', async (payload) => {
    try {
      const msg = String(payload?.message || '').trim().slice(0, 500);
      if (!msg) return;

      const userId = socket.data.userId;     // null ได้
      const username = socket.data.username; // ต้องมี

      if (!username) {
        socket.emit('chat:error', {
          message: 'Not identified. Please send chat:hello first.'
        });
        return;
      }

      await pool.query(
        `INSERT INTO chat_messages (room_id, user_id, username, message)
         VALUES ($1, $2, $3, $4)`,
        [1, userId, username, msg]
      );

      io.emit('chat:new', {
        userId,
        username,
        message: msg,
        created_at: new Date().toISOString(),
      });

    } catch (err) {
      console.error('chat:send error', err.code || err.message);
      socket.emit('chat:error', {
        message: `Send failed: ${err.code || err.message}`
      });
    }
  });

  // ==================================================
  // DM: join private room
  // ==================================================
  socket.on('dm:join', async ({ roomId }) => {
    try {
      const rid = Number(roomId);
      const userId = socket.data.userId;

      if (!rid || !userId) return;

      const ok = await isRoomMember(rid, userId);
      if (!ok) {
        socket.emit('dm:error', {
          message: 'Not allowed to join this room'
        });
        return;
      }

      socket.join(`room:${rid}`);
      socket.emit('dm:joined', { roomId: rid });

    } catch (err) {
      console.error('dm:join error:', err.message);
    }
  });

  // ==================================================
  // DM: send message
  // ==================================================
  socket.on('dm:send', async ({ roomId, message }) => {
    try {
      const rid = Number(roomId);
      const msg = String(message || '').trim().slice(0, 1000);

      const userId = socket.data.userId;
      const username = socket.data.username;

      if (!rid || !msg || !userId || !username) return;

      const ok = await isRoomMember(rid, userId);
      if (!ok) {
        socket.emit('dm:error', {
          message: 'Not allowed to send message'
        });
        return;
      }

      await pool.query(
        `INSERT INTO chat_messages (room_id, user_id, username, message)
         VALUES ($1, $2, $3, $4)`,
        [rid, userId, username, msg]
      );

      io.to(`room:${rid}`).emit('dm:new', {
        roomId: rid,
        userId,
        username,
        message: msg,
        created_at: new Date().toISOString(),
      });

      // Notify other participants (badge refresh) even if they are not in the room view
      try {
        const members = await pool.query(
          `SELECT user_id FROM chat_room_members WHERE room_id=$1 AND user_id <> $2`,
          [rid, userId]
        );
        for (const m of members.rows) {
          io.to(`user:${m.user_id}`).emit('dm:notify', { roomId: rid });
        }
      } catch (e) {
        console.warn('dm:notify failed:', e.code || e.message);
      }

    } catch (err) {
      console.error('dm:send error:', err.code || err.message);
      socket.emit('dm:error', { message: 'Send failed' });
    }
  });
});

// --------------------
// Start server
// --------------------
const PORT = process.env.PORT || 8080;

(async () => {
  try {
    await pool.query('SELECT 1');
    console.log('✅ PostgreSQL connected');
  } catch (e) {
    console.error('❌ PostgreSQL connect failed:', e.message);
  }

  try {
    await initDb();
    console.log('✅ Database schema ready');
  } catch (e) {
    console.warn(
      '⚠️ Schema not applied (permission/db mismatch):',
      e.code || e.message
    );
  }

  server.listen(PORT, () => {
    console.log(`✅ Server running on port ${PORT}`);
  });
})();
